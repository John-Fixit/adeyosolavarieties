// export const baseUrl = "https://adeyosolavarieties.vercel.app"
export const baseUrl = "https://adeyosolab.onrender.com"
// export const baseUrl = "http://localhost:4000"